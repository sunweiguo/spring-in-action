package com.njupt.swg.service;

public interface CD {
	public void play();
}
