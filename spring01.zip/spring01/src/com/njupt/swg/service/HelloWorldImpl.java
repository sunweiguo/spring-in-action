package com.njupt.swg.service;

public class HelloWorldImpl implements HelloWorld{

	@Override
	public String sayHi() {
		 return "Hello World from spring"; 
	}

}
