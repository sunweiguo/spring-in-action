package com.njupt.swg.service;

public interface HelloWorld {
	public String sayHi();  
}
