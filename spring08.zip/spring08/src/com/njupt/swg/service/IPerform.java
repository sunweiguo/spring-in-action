package com.njupt.swg.service;

public interface IPerform {
	public void perform();
}
