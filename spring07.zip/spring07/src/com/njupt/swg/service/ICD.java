package com.njupt.swg.service;

public interface ICD {
	public void play();
}
