package com.njupt.swg.service;

public interface MediaPlayer {
	public void play();
}
