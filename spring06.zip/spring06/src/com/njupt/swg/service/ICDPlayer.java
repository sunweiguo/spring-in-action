package com.njupt.swg.service;

public interface ICDPlayer {
	public void play();
}
