package com.njupt.swg.service;

public interface CompactDisc {
	public void play();
}
