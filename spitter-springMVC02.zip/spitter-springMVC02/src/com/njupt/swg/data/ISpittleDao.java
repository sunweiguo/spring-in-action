package com.njupt.swg.data;

import java.util.List;

import com.njupt.swg.bean.Spittle;

public interface ISpittleDao {
	public List<Spittle> findSpittles();
}
